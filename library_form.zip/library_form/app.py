from flask import Flask, render_template, request, redirect
import mysql.connector

app = Flask(__name__)

# DB connection
conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",  # Use your MySQL password if set
    database="school_results"
)
cursor = conn.cursor()

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        title = request.form['title']
        author = request.form['author']
        isbn = request.form['isbn']
        category = request.form['category']
        quantity = request.form['quantity']

        sql = "INSERT INTO books (title, author, isbn, category, quantity) VALUES (%s, %s, %s, %s, %s)"
        values = (title, author, isbn, category, quantity)
        cursor.execute(sql, values)
        conn.commit()
        return redirect('/')

    return render_template('form.html')

@app.route('/dashboard')
def dashboard():
    cursor.execute("SELECT * FROM books")
    books = cursor.fetchall()
    return render_template('dashboard.html', books=books)

if __name__ == '__main__':
    app.run(debug=True)